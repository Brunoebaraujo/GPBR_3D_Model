# Ferrolho MB6 — edição no FreeCAD

## Abrir e editar

1. Extraia o ZIP inteiro.
2. No FreeCAD, abra **Ferrolho_MB6.FCStd** por Arquivo > Abrir.
3. Na árvore do modelo, dê duplo clique em **00 - Medidas editaveis (mm)**.
4. Altere os valores na coluna **B**. As peças se atualizam a partir desses valores.
5. Volte à aba 3D para conferir. Se necessário, use Documento > Recalcular.
6. Salve como **Ferrolho_MB6_revisado.FCStd** e devolva esse arquivo.

Você não precisa executar macros, instalar extensões ou importar DAE.
O arquivo FCStd é o original paramétrico. STEP é uma cópia de intercâmbio
com sólidos: não mantém a tabela e o histórico de parâmetros.

## O que é editável

- Chapa: largura, altura e espessura.
- Receptor: largura, altura, profundidade e posição.
- Pino: comprimento, altura, espessura, posição e deslocamento.
- Haste: largura, altura, espessura e posição.
- Argola: raio central, raio da seção, escala vertical e posição.

A coluna C descreve os parâmetros. Use unidades mm nos comprimentos.
As células usam fórmulas simples: por exemplo, `=150 mm` ou `=-35 mm`.
Ao editar valores negativos, mantenha o sinal `=` inicial.
**EscalaArgola** é um fator sem unidade.
**Curso** desloca pino, haste e argola juntos: 0 mm é recolhido;
38 mm é o avanço usado hoje no simulador.

As dimensões das caixas estão vinculadas à tabela. Para alterá-las, edite
a tabela, pois sobrescrever propriedades com expressões não é o fluxo recomendado.
Para criar furos, chanfros ou outras alterações, use as ferramentas do FreeCAD
e salve o documento inteiro. As peças são sólidos separados.

## Organização

01 Chapa base / 02 Receptor / 03 Pino / 04 Haste / 05 Argola.
O perfil circular da argola fica oculto: ele gera a argola alongada por
um clone paramétrico do Draft, ferramenta padrão do FreeCAD.
O indicador colorido opcional do simulador também fica oculto e não entra
no STEP do conjunto; há um STEP individual dele.

Os STEP individuais preservam as posições de montagem.
Eixos: X horizontal, Z vertical e -Y para fora da parede.
Origem: centro da chapa-base.

## Referência e limitações

As cotas reproduzem aproximações visuais do simulador, não medições do
fabricante. O objetivo é permitir que você as corrija.
O ferrolho começa com pino recolhido e alça rebatida.
O modelo não tem animação, vínculos cinemáticos nem verificação automática
de interferência entre peças. Alterar uma cota pode exigir ajustar as posições.
O perfil da argola mantém a escala vertical de 1,75 do simulador, inclusive
na seção do tubo. É um sólido curvo editável, não uma malha triangulada.

## Devolver para integração

Envie o **.FCStd revisado** aqui ou suba em uma pasta do mesmo repositório.
Se possível, envie também um **.STEP** exportado só com as cinco peças finais:
selecione-as na árvore e use Arquivo > Exportar > STEP.
Evite selecionar o perfil oculto que gera a argola.
Mantenha as peças separadas e seus nomes, para facilitar a reintegração
dos movimentos do pino e da alça.
Editar o arquivo não atualiza o site automaticamente: a integração será feita depois.
