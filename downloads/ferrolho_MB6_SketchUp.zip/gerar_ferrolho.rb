# encoding: UTF-8
# Execute no Console Ruby do SketchUp Desktop com load "caminho/gerar_ferrolho.rb"
require 'sketchup.rb'
require 'json'
module GPBRFerrolhoExport
  def self.run
    data = JSON.parse(File.read(File.join(__dir__, 'geometria_mm.json'), encoding: 'UTF-8'))
    model = Sketchup.active_model
    model.start_operation('Criar ferrolho MB6 editavel', true)
    begin
      assembly = model.definitions.add('Ferrolho_MB6_referencia_aproximada')
      data.each do |part|
        definition = model.definitions.add(part['name'])
        material = model.materials.add('MB6_' + part['name'])
        material.color = part['color']
        points = part['vertices'].map { |v| Geom::Point3d.new(*v.map { |n| n.mm }) }
        part['faces'].each do |indices|
          face = definition.entities.add_face(indices.map { |i| points[i] })
          raise "Face invalida: #{part['name']}" unless face
          face.material = material
          face.back_material = material
        end
        definition.set_attribute('GPBR', 'origem', 'Simulador MB6; medidas aproximadas')
        instance = assembly.entities.add_instance(definition, Geom::Transformation.new)
        instance.name = part['name']
      end
      instance = model.entities.add_instance(assembly, Geom::Transformation.new)
      instance.name = 'Ferrolho MB6 - editar componentes internos'
      model.commit_operation
    rescue => error
      model.abort_operation
      UI.messagebox("Falha ao gerar o ferrolho: #{error.message}")
      return
    end
    model.selection.clear
    model.selection.add(instance)
    model.active_view.zoom(instance)
    path = UI.savepanel('Salvar somente o ferrolho em SKP', __dir__, 'ferrolho_MB6.skp')
    return unless path
    path += '.skp' unless File.extname(path).downcase == '.skp'
    if File.exist?(path)
      return unless UI.messagebox('Substituir o arquivo existente?', MB_YESNO) == IDYES
    end
    UI.messagebox(assembly.save_as(path) ? "Ferrolho salvo em #{path}" : 'Nao foi possivel salvar o SKP.')
  end
end
GPBRFerrolhoExport.run
