# Ferrolho MB6 para edição

Este pacote reproduz o ferrolho do simulador, com o pino recolhido e a alça rebatida.
As medidas são aproximações visuais do código, não medições do fabricante.
O indicador colorido é apenas uma peça visual opcional; não é ferragem confirmada.

## Caminho mais simples: importar
No SketchUp Desktop, use Arquivo > Importar > COLLADA (*.dae) e escolha
ferrolho_MB6.dae. Ative Mesclar faces coplanares. Depois salve como .skp.
Defina a exibição das unidades em milímetros e confira a chapa-base: largura 150 mm.
Use duplo clique para acessar as peças internas. Também há um DAE para cada peça.
Os arquivos individuais preservam a posição de montagem no conjunto.

## Criar componentes nativos e salvar em SKP
Extraia todo o ZIP na mesma pasta. No SketchUp Desktop, abra o Console Ruby
e execute, substituindo o caminho pela pasta extraída:

    load "C:/caminho/gerar_ferrolho.rb"

O script cria seis componentes separados e abre a janela para salvar somente
o conjunto em .skp, sem incluir os demais objetos do seu documento.
Para salvar uma peça isolada, entre no conjunto, selecione o componente
e use Salvar como no menu de contexto.
O script requer SketchUp Desktop com API Ruby; não funciona no SketchUp Web.
Não foi executado no SketchUp neste ambiente.

## Medidas de referência
Dimensões abaixo em mm, largura × altura × profundidade no simulador:
- Chapa-base: 150 × 50 × 14.
- Receptor: 25 × 45 × 35.
- Pino deslizante: 120 × 14 × 14. Curso no simulador: 38.
- Haste da alça: 16 × 70 × 15.
- Argola: envelope 62 × 108,5 × 12; raio central 25 e seção nominal 6,
  com escala vertical 1,75 aplicada, como no simulador.
- Indicador opcional: 65 × 18 × 5.

Eixos exportados: X horizontal, Z vertical, -Y para fora da parede.
Origem: centro da chapa-base. O modelo representa uma das orientações
do ferrolho; os vértices opostos usam a montagem espelhada.
As peças são geometria editável, sem restrições paramétricas ou animação.
As alterações no SketchUp não atualizam automaticamente o site.
Após editar, exporte o conjunto para DAE para permitir a reintegração.

Fontes:
https://help.sketchup.com/en/sketchup/importing-and-exporting-collada-files
https://ruby.sketchup.com/Sketchup/ComponentDefinition.html#save_as-instance_method
